/**
 * id - 207237421.
 */
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;
import java.awt.Color;

/***
 * the game class.
 */
public class Game {
    static final int BOARD_WIDTH = 800;
    static final int BOARD_HEIGHT = 600;
    static final int BOARDER_SHOT_SIDE = 20;

    static final int BLOCK_HEIGHT = 20;
    static final int BLOCK_WIDTH = 50;

    static final int PADDLE_HEIGHT = 20;
    static final int PADDLE_WIDTH = 150;

    private SpriteCollection sprites;
    private GameEnvironment environment;
    private Sleeper sleeper;
    private GUI gui;
    private Counter remainingBlocks;
    private Counter remainingBalls;
    private ScoreTrackingListener scoreTrackingListener;

    /***
     * add a new collidable to the list.
     * @param c - the collidable.
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /***
     * remove the collidable.
     * @param c - the collidable.
     */
    public void removeCollidable(Collidable c) {
        this.environment.removeCollidable(c);
    }

    /***
     * remove the sprite.
     * @param s - the sprite.
     */
    public void removeSprite(Sprite s) {
        this.sprites.removeSprite(s);
    }

    /***
     * add new sprite to the list.
     * @param s the sprite.
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }

    /***
     * Initialize a new game: create the Blocks and Ball (and Paddle) and add them to the game.
     */
    public void initialize() {
        int width = BOARD_WIDTH;
        int height = BOARD_HEIGHT;
        sprites = new SpriteCollection();
        environment = new GameEnvironment();
        sleeper = new Sleeper();
        gui = new GUI("Game", width, height);
        DrawSurface d = gui.getDrawSurface();
        this.remainingBlocks = new Counter(0);
        this.remainingBalls = new Counter(0);

        //this part prints the frame
        //score
        Counter scoreCounter = new Counter(0);
        this.scoreTrackingListener = new ScoreTrackingListener(scoreCounter);

        Point topScore = new Point(0, 0);
        Rectangle rectScore = new Rectangle(topScore, width + BOARDER_SHOT_SIDE, BOARDER_SHOT_SIDE);
        ScoreIndicator scoreIndicator = new ScoreIndicator(scoreCounter, rectScore, Color.white);
        scoreIndicator.addToGame(this);

        //boundaries
        Point top = new Point(0, 20);
        Rectangle rectLeft = new Rectangle(top, BOARDER_SHOT_SIDE, height);
        Block leftFrame = new Block(rectLeft, Color.gray);
        leftFrame.addToGame(this);

        Rectangle rectTop = new Rectangle(top, width, BOARDER_SHOT_SIDE);
        Block topFrame = new Block(rectTop, Color.gray);
        topFrame.addToGame(this);

        Point right = new Point(width - BOARDER_SHOT_SIDE, BOARDER_SHOT_SIDE);
        Rectangle rectRight = new Rectangle(right, BOARDER_SHOT_SIDE, height);
        Block rightFrame = new Block(rectRight, Color.gray);
        rightFrame.addToGame(this);

        BallRemover ballRemover = new BallRemover(this, this.remainingBalls);

        Point bottom = new Point(0, height - BOARDER_SHOT_SIDE);
        Rectangle rectBottom = new Rectangle(bottom, width, BOARDER_SHOT_SIDE);
        Block bottomFrame = new Block(rectBottom, Color.gray);
        bottomFrame.addHitListener(ballRemover);
        bottomFrame.addToGame(this);

        //this part prints the ball
        Ball ball1 = new Ball(300.0, 300.0, 5, Color.red, this.environment);
        ball1.addToGame(this);
        ball1.setVelocity(-2.0, -1.5);
        ball1.setBounds(800);

        Ball ball2 = new Ball(200.0, 250.0, 5, Color.red, this.environment);
        ball2.addToGame(this);
        ball2.setVelocity(1.0, -1.0);
        ball2.setBounds(800);
        this.remainingBalls.increase(2);

        Color[] colors = {Color.blue, Color.magenta, Color.pink, Color.orange, Color.green, Color.cyan};

        //this part prints the paddle
        Point paddlePoint = new Point(367.5, height - BOARDER_SHOT_SIDE - PADDLE_HEIGHT);
        Rectangle paddleRect = new Rectangle(paddlePoint, PADDLE_WIDTH, PADDLE_HEIGHT);
        Paddle paddle = new Paddle(paddleRect, Color.darkGray, gui);
        paddle.addToGame(this);

        PrintingHitListener print = new PrintingHitListener();
        BlockRemover blockRemover = new BlockRemover(this, this.remainingBlocks);

        //this part prints the blocks
        for (int i = 0; i <= 5; i++) {
            for (int j = 1; j < 12 - i; j++) {
                Point point = new Point(width - BOARDER_SHOT_SIDE - (j * BLOCK_WIDTH), 150 + (i * BLOCK_HEIGHT));
                Rectangle rect = new Rectangle(point, BLOCK_WIDTH, BLOCK_HEIGHT);
                Block block = new Block(rect, colors[i]);
                block.addHitListener(blockRemover);
                block.addHitListener(this.scoreTrackingListener);
                this.remainingBlocks.increase(1);
                block.addToGame(this);
            }
        }

    }

    /***
     * Run the game -- start the animation loop.
     */
    public void run() {
        int count = 0;
        int framesPerSecond = 60;
        int millisecondsPerFrame = 1000 / framesPerSecond;
        while (true) {
            long startTime = System.currentTimeMillis(); // timing

            DrawSurface d = gui.getDrawSurface();
            this.sprites.notifyAllTimePassed();
            this.sprites.drawAllOn(d);
            gui.show(d);
            if (remainingBalls.getValue() == 0) {
                gui.close();
            }
            if (remainingBlocks.getValue() == 0) {
                this.scoreTrackingListener.getCounter().increase(100);
                gui.close();
            }
            // timing
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
//            if (this.remainingBlocks.getValue() == 3) {
//                this.gui.close();
//                return;
//            }
        }

    }
}