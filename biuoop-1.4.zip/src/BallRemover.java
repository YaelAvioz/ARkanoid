/***
 * id: 207237421.
 * this class define a ball remover.
 */
public class BallRemover implements HitListener {
    private Game game;
    private Counter remainingBalls;

    /***
     * this is the constructor.
     * @param game - the game.
     * @param removedBalls - the ball.
     */
    public BallRemover(Game game, Counter removedBalls) {
        this.game = game;
        this.remainingBalls = removedBalls;
    }

    /***
     * decrease the balls counter and remove the ball from the game.
     * @param beingHit - the block was hit.
     * @param hitter - The hitter parameter is the Ball that's doing the hitting.
     */
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        remainingBalls.decrease(1);
        hitter.removeFromGame(this.game);
    }
}
