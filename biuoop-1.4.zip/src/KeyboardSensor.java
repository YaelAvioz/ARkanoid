/***
 * id: 207237421.
 * the keyboard sensor.
 */
public interface KeyboardSensor {
    String RIGHT_KEY = Character.toString((char) 39);
    String LEFT_KEY = Character.toString((char) 37);
}
