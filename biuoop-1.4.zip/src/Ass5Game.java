/**
 * id: 207237421.
 * Main class.
 */
public class Ass5Game {
    /***
     * the main of the game class.
     * @param args - the parameters.
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}
