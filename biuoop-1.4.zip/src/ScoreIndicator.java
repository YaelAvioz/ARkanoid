/***
 * id - 207237421
 */
import biuoop.DrawSurface;
import java.awt.Color;

/***
 * this class defines the score.
 */
public class ScoreIndicator implements Sprite {

    private Rectangle rect;
    private java.awt.Color color;
    private Counter scoreCounter;

    /***
     * this is the constructor.
     * @param scoreCounter - the counter of the scores.
     * @param rect - the rectangle.
     * @param color -  the color of the rectangle.
     */
    public ScoreIndicator(Counter scoreCounter, Rectangle rect, java.awt.Color color) {
        this.rect = rect;
        this.color = color;
        this.scoreCounter = scoreCounter;
    }

    /***
     * draw the image to the game.
     * @param surface - the draw of the block.
     */
    @Override
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.color);
        Point upperLeft = this.rect.getUpperLeft();
        double w = this.rect.getWidth();
        double h = this.rect.getHeight();
        surface.fillRectangle((int) upperLeft.getX(), (int) upperLeft.getY(), (int) w, (int) h);
        surface.setColor(Color.black);
        surface.drawRectangle((int) upperLeft.getX(), (int) upperLeft.getY(), (int) w, (int) h);
        int centerX = (int) ((int) upperLeft.getX() + w / 2 - 50);
        int centerY = (int) ((int) upperLeft.getY() + h - 5);
        String scoreString = String.format("Score: %d", scoreCounter.getValue());
        surface.drawText(centerX, centerY, scoreString, 15);
    }

    /***
     * add the score to the game.
     * @param g - the game.
     */
    public void addToGame(Game g) {
        g.addSprite(this);
    }
    @Override
    public void timePassed() {
    }
}
